$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
[xml]$doc = Get-Content -LiteralPath (Join-Path $root 'timeline.xml') -Raw
foreach ($node in $doc.SelectNodes('//pathurl')) {
  $relative = $node.InnerText.Replace('file://localhost/CLIP_MAKER_PACKAGE/', '')
  $target = [IO.Path]::GetFullPath((Join-Path $root $relative))
  if (-not $target.StartsWith($root + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid media path' }
  if (-not (Test-Path -LiteralPath $target)) { throw 'Media file missing' }
  $node.InnerText = ([Uri]$target).AbsoluteUri
}
$doc.Save((Join-Path $root 'timeline-local.xml'))
Write-Host 'Import timeline-local.xml into Premiere Pro.'
